package sg.nus.iss.adproject.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sg.nus.iss.adproject.entities.User;
import sg.nus.iss.adproject.repositories.UserRepository;


@Service
@Transactional
public class UserService implements UserInterface{

	@Autowired
	private UserRepository ur;

	@Override
	public User login(String username, String password) {
		return ur.findUserByUsernameAndPassword(username, password);
	}
}
