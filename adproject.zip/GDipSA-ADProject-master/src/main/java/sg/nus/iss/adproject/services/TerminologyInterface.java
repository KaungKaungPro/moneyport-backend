package sg.nus.iss.adproject.services;

import sg.nus.iss.adproject.entities.Terminology;

import java.util.List;

public interface TerminologyInterface {

    List<Terminology> getAllTerminology(String term);
}
