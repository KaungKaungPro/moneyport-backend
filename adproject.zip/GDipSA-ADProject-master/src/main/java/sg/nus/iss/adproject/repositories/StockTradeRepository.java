package sg.nus.iss.adproject.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import sg.nus.iss.adproject.entities.simulation.StockTrade;

public interface StockTradeRepository extends JpaRepository<StockTrade, Integer>{

	@Query("SELECT st FROM StockTrade st WHERE st.stock.stockCode = :stockCode AND st.dateTraded = :date ORDER BY st.timeTraded")
	List<StockTrade> getStockTradeByStockCodeByIntraDay(@Param("stockCode") String stockCode, @Param("date") LocalDate date);
	
	@Query("SELECT st FROM StockTrade st WHERE st.stock.stockCode = :stockCode AND (st.dateTraded BETWEEN :startDate AND :endDate) ORDER BY st.dateTraded ASC, st.timeTraded ASC")
	List<StockTrade> getStockTradeByStockCodeByDateRange(@Param("stockCode") String stockCode, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);
	
	@Query("SELECT st FROM StockTrade st WHERE st.stock.stockCode = :stockCode")
	List<StockTrade> getStockTradeByStockCodeMax(@Param("stockCode") String stockCode);
}
