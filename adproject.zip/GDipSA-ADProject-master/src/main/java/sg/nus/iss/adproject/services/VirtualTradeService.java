package sg.nus.iss.adproject.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import sg.nus.iss.adproject.entities.simulation.MktSimParam;
import sg.nus.iss.adproject.entities.simulation.Stock;
import sg.nus.iss.adproject.entities.simulation.StockTrade;
import sg.nus.iss.adproject.entities.simulation.StockTradeViewMode;
import sg.nus.iss.adproject.entities.simulation.TradeInstruction;
import sg.nus.iss.adproject.entities.simulation.VirtualTradingGame;
import sg.nus.iss.adproject.repositories.MktSimParamRepository;
import sg.nus.iss.adproject.repositories.StockRepository;
import sg.nus.iss.adproject.repositories.StockTradeRepository;

@Service
@Transactional
public class VirtualTradeService implements VirtualTradeInterface{

	@Autowired
	private StockRepository sr;
	
	@Autowired
	private MktSimParamRepository mspr;
	
	@Autowired
	private StockTradeRepository str;
	
	private VirtualTradingGame game = null; 

	@Override
	public List<Stock> getStocks() {
		return sr.findAll();
	}
	
	@Override
	public MktSimParam getLatestMktSimParam() {
		List<MktSimParam> mktSimParams = mspr.getMktSimParamsOrderByCreationDate();
		if(mktSimParams.isEmpty()) {
			return null;
		}
		return mktSimParams.get(0);
	}
	
	@Override
	public void startVirtualTradeEnv() {
		if(game == null) {
			MktSimParam param = getLatestMktSimParam();
			List<Stock> stocks = getStocks();
			game = new VirtualTradingGame(str, param, stocks);
		}
	}
	
	
	@Override
	public void endTurn(List<TradeInstruction> instructions) {
		game.setInstructions(instructions);
		game.EndTurn();
	}
	
	@Override
	public List<StockTrade> getStockTrades(String stockCode, StockTradeViewMode mode){
		switch(mode) {
			case intraDay:
				LocalDate yesterday = LocalDate.now().minusDays(1);
				System.out.println("Date: " + yesterday);
				return str.getStockTradeByStockCodeByIntraDay(stockCode, yesterday);
			case week:
				return str.getStockTradeByStockCodeByDateRange(stockCode, LocalDate.now().minusDays(8), LocalDate.now().minusDays(1));
			case month:
				return str.getStockTradeByStockCodeByDateRange(stockCode, LocalDate.now().minusDays(31), LocalDate.now().minusDays(1));
			case year:
				return str.getStockTradeByStockCodeByDateRange(stockCode, LocalDate.now().minusYears(1), LocalDate.now().minusDays(1));
			case years10:
				return str.getStockTradeByStockCodeByDateRange(stockCode, LocalDate.now().minusYears(10), LocalDate.now().minusDays(1));
			case max:
				return str.getStockTradeByStockCodeMax(stockCode);
			default:
				return str.getStockTradeByStockCodeByIntraDay(stockCode, LocalDate.now().minusDays(1));
		}
	}
	
	@Override
	public void buildSingleDayTrade() {
		if(game == null) {
			startVirtualTradeEnv();
		}
		
		game.getMkt().buildSingleDayTrade(str, LocalDate.now().minusDays(1));
	}
}
