package sg.nus.iss.adproject.entities.simulation;

import sg.nus.iss.adproject.entities.User;

public class TradeInstruction {
	
	private TradeOp op;
	
	private User user;
	
	private int quantity;
	
	private double price;
	
	private Stock stock;
	
	public TradeInstruction() {}
	
	public TradeInstruction(TradeOp op, User user, int quantity, double price, Stock stock) {
		super();
		this.op = op;
		this.user = user;
		this.quantity = quantity;
		this.price = price;
		this.stock = stock;
	}

	public TradeOp getOp() {
		return op;
	}

	public void setOp(TradeOp op) {
		this.op = op;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}
	
	
}
