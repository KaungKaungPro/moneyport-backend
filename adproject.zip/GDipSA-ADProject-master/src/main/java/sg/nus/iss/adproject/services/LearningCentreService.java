package sg.nus.iss.adproject.services;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class LearningCentreService implements LearningCentreInterface{

}
