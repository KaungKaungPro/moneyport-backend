package sg.nus.iss.adproject.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import sg.nus.iss.adproject.entities.Terminology;

import java.util.List;

@Repository
public interface TerminologyRepository extends JpaRepository<Terminology, Integer> {

    List<Terminology> findByTermContaining(String term);

}
