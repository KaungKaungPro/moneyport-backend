package sg.nus.iss.adproject.entities.simulation;

public enum StockTradeViewMode {
	intraDay, week, month, year, years10, max 
}
