package sg.nus.iss.adproject.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import sg.nus.iss.adproject.services.UserInterface;


@RestController
@RequestMapping("/api/login")
@CrossOrigin
public class LoginController {
	
	@Autowired
	private UserInterface uService;

	@PostMapping("/login")
	public ResponseEntity<String> login(String username, String password){
		if(uService.login(username, password) != null) {
			return new ResponseEntity<>(HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
	
	
}
