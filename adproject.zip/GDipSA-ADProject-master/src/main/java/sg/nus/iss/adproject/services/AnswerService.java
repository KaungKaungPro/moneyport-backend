package sg.nus.iss.adproject.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sg.nus.iss.adproject.entities.Answer;
import sg.nus.iss.adproject.repositories.AnswerRepository;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class AnswerService implements AnswerInterface {
    @Autowired
    private AnswerRepository repository;

    @Override
    public List<Answer> getAllAnswer(int questionId) {
        List<Answer> list = repository.findAnswerByQuestionId(questionId);
        Optional<Answer> maxUpvoteAnswer = list.stream().max(Comparator.comparingInt(Answer::getUpVote));
        if (maxUpvoteAnswer.isPresent()) {
            Answer topAnswer = maxUpvoteAnswer.get();
            list.remove(topAnswer);
            list.sort(Comparator.comparing(Answer::getCreateTime).reversed());
            list.add(0, topAnswer);
        }
        return list;
    }

    @Override
    @Transactional
    public void add(Answer answer) {
        repository.save(answer);
    }

    @Override
    @Transactional
    public void editUpVote(Answer answer) {
        Optional<Answer> optional = repository.findById(answer.getId().intValue());
        if (optional.isPresent()) {
            Answer item = optional.get();
            item.setUpVote(item.getUpVote() + 1);
            repository.save(item);
        }
    }

    @Override
    @Transactional
    public void editDownVote(Answer answer) {
        Optional<Answer> optional = repository.findById(answer.getId().intValue());
        if (optional.isPresent()) {
            Answer item = optional.get();
            item.setUpVote(item.getUpVote() -1);
            repository.save(item);
        }
    }

    @Override
    @Transactional
    public void delete(int answerId) {
        repository.deleteById(answerId);
    }
}
