package sg.nus.iss.adproject.services;

import java.util.List;

import sg.nus.iss.adproject.entities.simulation.MktSimParam;
import sg.nus.iss.adproject.entities.simulation.Stock;
import sg.nus.iss.adproject.entities.simulation.StockTrade;
import sg.nus.iss.adproject.entities.simulation.StockTradeViewMode;
import sg.nus.iss.adproject.entities.simulation.TradeInstruction;

public interface VirtualTradeInterface {

	List<Stock> getStocks();
	
	MktSimParam getLatestMktSimParam();
	
	void startVirtualTradeEnv();
	
	void endTurn(List<TradeInstruction> instructions);
	
	List<StockTrade> getStockTrades(String stockCode, StockTradeViewMode mode);
	
	void buildSingleDayTrade();
}
