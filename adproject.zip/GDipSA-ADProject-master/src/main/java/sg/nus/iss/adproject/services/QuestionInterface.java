package sg.nus.iss.adproject.services;

import sg.nus.iss.adproject.entities.Question;

import java.util.List;

public interface QuestionInterface {

    List<Question> getAllQuestion();

    void add(Question question);

    Question getQuestion(int questionId);

    void delete(int questionId);
}
