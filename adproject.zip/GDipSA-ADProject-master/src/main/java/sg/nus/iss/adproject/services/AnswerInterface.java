package sg.nus.iss.adproject.services;

import sg.nus.iss.adproject.entities.Answer;

import java.util.List;

public interface AnswerInterface {

    List<Answer> getAllAnswer(int questionId);

    void add(Answer answer);

    void editUpVote(Answer answer);

    void editDownVote(Answer answer);

    void delete(int answerId);
}
