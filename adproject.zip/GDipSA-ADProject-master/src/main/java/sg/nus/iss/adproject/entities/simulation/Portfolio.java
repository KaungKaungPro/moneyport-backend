package sg.nus.iss.adproject.entities.simulation;

import java.util.List;

import jakarta.persistence.*;
import sg.nus.iss.adproject.entities.User;

@Entity
public class Portfolio {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	private double v$;
	
	@ManyToOne
	private User user;
	
	@OneToMany(mappedBy="portfolio")
	private List<PortfolioStock> portfolioStocks;
	
	public Portfolio() {}

	public Portfolio(long id, User user, List<PortfolioStock> portfolioStocks) {
		super();
		this.id = id;
		this.user = user;
		this.portfolioStocks = portfolioStocks;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<PortfolioStock> getPortfolioStocks() {
		return portfolioStocks;
	}

	public void setPortfolioStocks(List<PortfolioStock> portfolioStocks) {
		this.portfolioStocks = portfolioStocks;
	}

}
