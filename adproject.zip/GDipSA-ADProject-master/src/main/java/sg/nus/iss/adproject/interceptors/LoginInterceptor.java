package sg.nus.iss.adproject.interceptors;

import org.springframework.web.servlet.HandlerInterceptor;

public class LoginInterceptor implements HandlerInterceptor{

}
