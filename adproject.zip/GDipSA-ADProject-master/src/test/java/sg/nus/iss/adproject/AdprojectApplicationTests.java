package sg.nus.iss.adproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
